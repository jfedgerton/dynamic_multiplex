from __future__ import annotations

from .multilayer_utils import (
    add_community_self_loops,
    community_overlap_edges,
    detect_interlayer_communities,
    fit_layer_communities,
    make_layer_links,
    prepare_multilayer_graphs,
)


def fit_multilayer_jaccard(
    layers,
    algorithm: str = "leiden",
    layer_links=None,
    min_similarity: float = 0.0,
    resolution_parameter: float = 1.0,
    directed: bool = False,
    add_self_loops: bool = True,
    self_loop_multiplier: float = 1.0,
    objective: str | None = None,
    seed: int | None = 123,
):
    """Fit per-layer communities and interlayer weighted Jaccard ties.

    Returns
    -------
    dict
        Keys include ``layer_communities`` (per-layer detection, detected
        independently), ``meta_communities`` (the cross-layer tracked
        partition from the second-stage detection -- one array per layer of
        each node's meta-community, reflecting the interlayer ties and any
        custom ``layer_links``, and the membership validated by
        ``bootstrap_multilayer``; see ``extract_meta_membership``),
        ``meta_ids``, ``interlayer_ties``, and ``layer_links``.
    """
    graph_layers = prepare_multilayer_graphs(layers, directed=directed)
    links = make_layer_links(len(graph_layers), layer_links)
    fit = fit_layer_communities(
        graph_layers,
        algorithm=algorithm,
        resolution_parameter=resolution_parameter,
        directed=directed,
        objective=objective,
        seed=seed,
    )

    interlayer_ties = community_overlap_edges(
        fit=fit,
        layer_links=links,
        metric="jaccard",
        min_similarity=min_similarity,
    )

    if add_self_loops:
        interlayer_ties = add_community_self_loops(
            edge_df=interlayer_ties,
            fit=fit,
            layer_links=links,
            self_loop_multiplier=self_loop_multiplier,
            min_similarity=min_similarity,
            directed=directed,
        )

    # Second-stage detection: group per-layer communities into cross-layer
    # meta-communities from the interlayer ties (the tracked partition).
    meta = detect_interlayer_communities(
        layer_communities=fit,
        interlayer_ties=interlayer_ties,
        algorithm=algorithm,
        resolution_parameter=resolution_parameter,
        seed=seed,
    )

    return {
        "algorithm": algorithm,
        "layer_communities": fit,
        "meta_communities": meta["membership"],
        "meta_ids": meta["meta_ids"],
        "layer_links": links,
        "interlayer_ties": interlayer_ties,
        "directed": directed,
        "node_labels": graph_layers[0].graph.get("node_labels"),
    }
